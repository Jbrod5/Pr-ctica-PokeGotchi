package com.jbravo.pokegotchi.app.consumibles;

public class Antibiotico extends Medicina{

    public Antibiotico(){
        super.aspecto = "/consumibles/Antibiotico.png";
        super.curarEnfermedades = 3;
    }
}
