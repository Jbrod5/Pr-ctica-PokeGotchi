package com.jbravo.pokegotchi.app.consumibles;

public class Manzana extends Comida{

    public Manzana(){
        super.aspecto = "/consumibles/Manzana.png";
        super.comidasParaMorir = 5;
    }
}
