package com.jbravo.pokegotchi.app.motor.tienda;

public class GenerarPokemon {
}
