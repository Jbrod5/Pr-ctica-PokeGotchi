package com.jbravo.pokegotchi.app.consumibles;

public class ComidaVacia extends Comida{

    public ComidaVacia (){

    }

}
