package com.jbravo.pokegotchi.app.consumibles;

public class Vitaminas extends Medicina{

    public Vitaminas(){
        super.aspecto ="/consumibles/Vitamina.png";
        super.curarEnfermedades = 1;
    }

}
