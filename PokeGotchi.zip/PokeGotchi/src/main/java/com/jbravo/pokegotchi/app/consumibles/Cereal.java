package com.jbravo.pokegotchi.app.consumibles;

public class Cereal extends Comida{

    public Cereal(){
        super.aspecto = "/consumibles/Cereal.png";
        super.comidasParaMorir = 5;
    }
}
