package com.jbravo.pokegotchi.app.consumibles;

public class Waffles extends Comida{

    public Waffles(){
        super.aspecto = "/consumibles/Waffles.png";
        super.comidasParaMorir = 10;
    }
}
