package com.jbravo.pokegotchi.app.consumibles;

public class Analgesico extends Medicina{

    public Analgesico(){
        super.aspecto = "/consumibles/Analgesico.png";
        super.curarEnfermedades = 2;
    }
}
